package com.example.jchen415.mywaytormobileapplication.Notifications;

public class MyResponse {

    public int success;
}
